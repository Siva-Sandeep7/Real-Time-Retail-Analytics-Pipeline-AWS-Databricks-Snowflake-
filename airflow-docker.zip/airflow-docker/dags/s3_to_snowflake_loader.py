from airflow import DAG
from airflow.providers.amazon.aws.sensors.s3 import S3KeySensor
from airflow.providers.snowflake.operators.snowflake import SnowflakeOperator
from datetime import datetime, timedelta

default_args = {
    'owner': 'airflow',
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    'start_date': datetime(2024, 1, 1),
}

with DAG(
    dag_id='s3_to_snowflake_loader',
    default_args=default_args,
    schedule_interval=None,
    catchup=False,
    tags=['s3', 'snowflake'],
    description='Load new .parquet files from S3 into Snowflake',
) as dag:

    wait_for_s3_file = S3KeySensor(
        task_id='wait_for_new_parquet_file',
        bucket_name='retail-data-lake-project-1',
        bucket_key='databricks-output/*.parquet',
        wildcard_match=True,
        aws_conn_id='aws_default',
        poke_interval=30,
        timeout=600,
        mode='poke',
    )

    load_to_snowflake = SnowflakeOperator(
        task_id='copy_into_snowflake_table',
        snowflake_conn_id='snowflake_conn',
        sql="""
        COPY INTO sales_data
        FROM @my_s3_stage/databricks-output
        FILE_FORMAT = (TYPE = PARQUET)
        MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
        ON_ERROR = 'CONTINUE';
        """
    )

    wait_for_s3_file >> load_to_snowflake
